package com.example.grandle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrandleApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrandleApplication.class, args);
	}

}
