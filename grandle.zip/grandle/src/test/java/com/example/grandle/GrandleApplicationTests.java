package com.example.grandle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrandleApplicationTests {

	@Test
	void contextLoads() {
	}

}
