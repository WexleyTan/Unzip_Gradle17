package com.example.gradle14_new;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Gradle14NewApplicationTests {

    @Test
    void contextLoads() {
    }

}
