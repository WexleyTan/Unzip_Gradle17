package com.example.gradle14_new;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Gradle14NewApplication {

    public static void main(String[] args) {
        SpringApplication.run(Gradle14NewApplication.class, args);
    }

}
